# Overview

This is a lightweight algorithmic trading platform built with Streamlit designed specifically for retail traders. The platform provides essential market analysis tools, risk management calculators, and trading insights in a fast-loading, streamlined interface. It focuses on the core features that individual traders need most while emphasizing proper risk management practices and quick decision-making capabilities.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: Streamlit with multi-page application structure
- **Layout**: Wide layout with expandable sidebar for navigation
- **Visualization**: Plotly for interactive charts and graphs
- **State Management**: Streamlit session state for maintaining user data across pages
- **Page Structure**: Main dashboard (app.py) with separate pages for specialized functions

## Backend Architecture
- **Data Processing**: Pandas for data manipulation and analysis
- **Technical Analysis Engine**: Custom technical indicators class with TA-Lib integration
- **Risk Management Engine**: Dedicated risk calculation and position sizing algorithms
- **Portfolio Management**: Session-based portfolio tracking with real-time updates
- **Backtesting Engine**: Simple backtesting system for strategy validation

## Data Management
- **Market Data**: Real-time and historical stock data via yfinance API
- **Caching Strategy**: Streamlit's built-in caching with 5-minute TTL for market data
- **Data Storage**: Session-state based storage for user portfolios and watchlists
- **Data Validation**: Error handling and data quality checks for market data feeds

## Risk Management Framework
- **Position Sizing**: Kelly Criterion and fixed percentage risk models
- **Stop Loss Calculations**: Multiple methods including percentage-based and ATR-based
- **Portfolio Risk**: Concentration limits and correlation analysis
- **Monte Carlo Simulation**: Statistical risk modeling capabilities

## Technical Analysis System
- **Indicator Library**: Moving averages, RSI, MACD, Bollinger Bands, Stochastic oscillators
- **Chart Analysis**: Multi-timeframe analysis with customizable technical overlays
- **Signal Generation**: Buy/sell signal detection based on technical indicators
- **Pattern Recognition**: Support for various chart patterns and trend analysis

## Educational Framework
- **Interactive Learning**: Live examples using real market data
- **Progressive Curriculum**: From basic concepts to advanced trading strategies
- **Risk Education**: Emphasis on proper risk management and trading psychology
- **Practical Examples**: Hands-on calculators and simulators for learning

# External Dependencies

## Market Data Services
- **yfinance**: Primary data source for real-time and historical stock market data
- **Yahoo Finance API**: Underlying data provider for stock prices, company information, and market indices

## Technical Analysis Libraries
- **TA-Lib**: Professional technical analysis library for indicator calculations
- **NumPy**: Mathematical operations and array processing for technical computations
- **Pandas**: Data manipulation and time series analysis

## Visualization and UI
- **Streamlit**: Web application framework and hosting platform
- **Plotly**: Interactive charting and data visualization
- **Plotly Express**: Simplified plotting interface for quick visualizations

## Data Processing
- **Pandas**: DataFrame operations and data analysis
- **NumPy**: Numerical computations and statistical analysis
- **Python Warnings**: Error handling and user notification system

## Development Dependencies
- **Datetime**: Date and time handling for market data and trading calculations
- **JSON**: Data serialization for portfolio and configuration storage
- **Math**: Mathematical functions for risk calculations and statistical analysis
import pandas as pd
import numpy as np
import streamlit as st

class RiskManager:
    """
    Risk management tools for trading
    """
    
    def calculate_position_size(self, account_size: float, risk_percentage: float, 
                              entry_price: float, stop_loss_price: float) -> int:
        """
        Calculate position size based on risk management rules
        
        Args:
            account_size (float): Total account size
            risk_percentage (float): Risk percentage per trade
            entry_price (float): Entry price per share
            stop_loss_price (float): Stop loss price per share
            
        Returns:
            int: Number of shares to buy
        """
        if entry_price <= 0 or stop_loss_price <= 0:
            return 0
        
        risk_amount = account_size * (risk_percentage / 100)
        price_difference = abs(entry_price - stop_loss_price)
        
        if price_difference <= 0:
            return 0
        
        position_size = int(risk_amount / price_difference)
        max_position = int(account_size * 0.1 / entry_price)  # Max 10% of account in single stock
        
        return min(position_size, max_position)
    
    def calculate_stop_loss(self, entry_price: float, method: str = "percentage", 
                          percentage: float = 3.0, atr_multiplier: float = 2.0, 
                          atr_value: float = None) -> float:
        """
        Calculate stop loss price using different methods
        
        Args:
            entry_price (float): Entry price
            method (str): "percentage" or "atr"
            percentage (float): Stop loss percentage
            atr_multiplier (float): ATR multiplier
            atr_value (float): ATR value
            
        Returns:
            float: Stop loss price
        """
        if method == "percentage":
            return entry_price * (1 - percentage / 100)
        elif method == "atr" and atr_value:
            return entry_price - (atr_multiplier * atr_value)
        else:
            return entry_price * 0.97  # Default 3% stop loss
    
    def calculate_take_profit(self, entry_price: float, stop_loss_price: float, 
                            risk_reward_ratio: float = 2.0) -> float:
        """
        Calculate take profit price based on risk-reward ratio
        
        Args:
            entry_price (float): Entry price
            stop_loss_price (float): Stop loss price
            risk_reward_ratio (float): Risk to reward ratio
            
        Returns:
            float: Take profit price
        """
        risk = entry_price - stop_loss_price
        reward = risk * risk_reward_ratio
        return entry_price + reward
    
    def portfolio_risk_metrics(self, returns: pd.Series) -> dict:
        """
        Calculate portfolio risk metrics
        
        Args:
            returns (pd.Series): Portfolio returns
            
        Returns:
            dict: Risk metrics
        """
        if returns.empty:
            return {}
        
        metrics = {}
        
        # Basic statistics
        metrics['Total Return'] = (returns + 1).prod() - 1
        metrics['Annualized Return'] = (1 + metrics['Total Return']) ** (252 / len(returns)) - 1
        metrics['Volatility'] = returns.std() * np.sqrt(252)
        
        # Sharpe Ratio (assuming 2% risk-free rate)
        risk_free_rate = 0.02
        metrics['Sharpe Ratio'] = (metrics['Annualized Return'] - risk_free_rate) / metrics['Volatility'] if metrics['Volatility'] > 0 else 0
        
        # Maximum Drawdown
        cumulative = (1 + returns).cumprod()
        running_max = cumulative.expanding().max()
        drawdown = (cumulative - running_max) / running_max
        metrics['Max Drawdown'] = drawdown.min()
        
        # Value at Risk (95% confidence)
        metrics['VaR_95'] = returns.quantile(0.05)
        
        # Calmar Ratio
        metrics['Calmar Ratio'] = metrics['Annualized Return'] / abs(metrics['Max Drawdown']) if metrics['Max Drawdown'] != 0 else 0
        
        # Win Rate
        winning_trades = len(returns[returns > 0])
        total_trades = len(returns[returns != 0])
        metrics['Win Rate'] = winning_trades / total_trades if total_trades > 0 else 0
        
        # Average Win/Loss
        winners = returns[returns > 0]
        losers = returns[returns < 0]
        metrics['Avg Win'] = winners.mean() if len(winners) > 0 else 0
        metrics['Avg Loss'] = losers.mean() if len(losers) > 0 else 0
        metrics['Win/Loss Ratio'] = abs(metrics['Avg Win'] / metrics['Avg Loss']) if metrics['Avg Loss'] != 0 else 0
        
        return metrics
    
    def kelly_criterion(self, win_rate: float, avg_win: float, avg_loss: float) -> float:
        """
        Calculate Kelly Criterion for optimal position sizing
        
        Args:
            win_rate (float): Probability of winning
            avg_win (float): Average win amount
            avg_loss (float): Average loss amount (positive number)
            
        Returns:
            float: Kelly percentage
        """
        if avg_loss <= 0 or win_rate <= 0 or win_rate >= 1:
            return 0
        
        b = avg_win / avg_loss  # Odds
        p = win_rate  # Probability of win
        q = 1 - p  # Probability of loss
        
        kelly_pct = (b * p - q) / b
        return max(0, min(kelly_pct, 0.25))  # Cap at 25%
    
    def monte_carlo_simulation(self, returns: pd.Series, initial_capital: float = 10000, 
                             num_simulations: int = 1000, days: int = 252) -> dict:
        """
        Run Monte Carlo simulation on returns
        
        Args:
            returns (pd.Series): Historical returns
            initial_capital (float): Starting capital
            num_simulations (int): Number of simulations
            days (int): Number of trading days to simulate
            
        Returns:
            dict: Simulation results
        """
        if returns.empty:
            return {}
        
        # Calculate return statistics
        mean_return = returns.mean()
        std_return = returns.std()
        
        # Run simulations
        final_values = []
        
        for _ in range(num_simulations):
            daily_returns = np.random.normal(mean_return, std_return, days)
            portfolio_value = initial_capital
            
            for daily_return in daily_returns:
                portfolio_value *= (1 + daily_return)
            
            final_values.append(portfolio_value)
        
        final_values = np.array(final_values)
        
        results = {
            'Mean Final Value': np.mean(final_values),
            'Median Final Value': np.median(final_values),
            'Best Case (95th percentile)': np.percentile(final_values, 95),
            'Worst Case (5th percentile)': np.percentile(final_values, 5),
            'Probability of Loss': np.sum(final_values < initial_capital) / num_simulations,
            'Standard Deviation': np.std(final_values)
        }
        
        return results
    
    def correlation_analysis(self, prices_df: pd.DataFrame) -> pd.DataFrame:
        """
        Analyze correlation between different assets
        
        Args:
            prices_df (pd.DataFrame): DataFrame with asset prices
            
        Returns:
            pd.DataFrame: Correlation matrix
        """
        if prices_df.empty:
            return pd.DataFrame()
        
        returns = prices_df.pct_change().dropna()
        correlation_matrix = returns.corr()
        
        return correlation_matrix
    
    def diversification_ratio(self, weights: np.array, cov_matrix: np.ndarray) -> float:
        """
        Calculate diversification ratio
        
        Args:
            weights (np.array): Portfolio weights
            cov_matrix (np.ndarray): Covariance matrix
            
        Returns:
            float: Diversification ratio
        """
        if len(weights) == 0 or cov_matrix.size == 0:
            return 0
        
        # Weighted average of individual volatilities
        individual_vol = np.sqrt(np.diag(cov_matrix))
        weighted_avg_vol = np.sum(weights * individual_vol)
        
        # Portfolio volatility
        portfolio_vol = np.sqrt(np.dot(weights.T, np.dot(cov_matrix, weights)))
        
        if portfolio_vol == 0:
            return 0
        
        return weighted_avg_vol / portfolio_vol
    
    def risk_parity_weights(self, cov_matrix: np.ndarray, max_iterations: int = 1000) -> np.array:
        """
        Calculate risk parity portfolio weights
        
        Args:
            cov_matrix (np.ndarray): Covariance matrix
            max_iterations (int): Maximum iterations for optimization
            
        Returns:
            np.array: Risk parity weights
        """
        n = cov_matrix.shape[0]
        
        # Start with equal weights
        weights = np.ones(n) / n
        
        for _ in range(max_iterations):
            # Calculate risk contributions
            portfolio_vol = np.sqrt(np.dot(weights.T, np.dot(cov_matrix, weights)))
            marginal_contrib = np.dot(cov_matrix, weights) / portfolio_vol
            risk_contrib = weights * marginal_contrib
            
            # Target risk contribution (equal for all assets)
            target_risk = np.ones(n) / n
            
            # Update weights
            weights = weights * np.sqrt(target_risk / risk_contrib)
            weights = weights / np.sum(weights)  # Normalize
            
            # Check convergence
            if np.allclose(risk_contrib / np.sum(risk_contrib), target_risk, atol=1e-6):
                break
        
        return weights

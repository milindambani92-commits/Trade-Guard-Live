import pandas as pd
import numpy as np
# import talib as ta  # TA-Lib not available, using manual calculations

class TechnicalIndicators:
    """
    Technical indicators for stock analysis
    """
    
    def moving_average(self, data: pd.Series, window: int) -> pd.Series:
        """
        Calculate Simple Moving Average
        
        Args:
            data (pd.Series): Price data
            window (int): Window size
            
        Returns:
            pd.Series: Moving average
        """
        return data.rolling(window=window).mean()
    
    def exponential_moving_average(self, data: pd.Series, window: int) -> pd.Series:
        """
        Calculate Exponential Moving Average
        
        Args:
            data (pd.Series): Price data
            window (int): Window size
            
        Returns:
            pd.Series: Exponential moving average
        """
        return data.ewm(span=window).mean()
    
    def rsi(self, data: pd.Series, window: int = 14) -> pd.Series:
        """
        Calculate Relative Strength Index
        
        Args:
            data (pd.Series): Price data
            window (int): Window size (default 14)
            
        Returns:
            pd.Series: RSI values
        """
        delta = data.diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=window).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=window).mean()
        rs = gain / loss
        return 100 - (100 / (1 + rs))
    
    def macd(self, data: pd.Series, fast_period: int = 12, slow_period: int = 26, signal_period: int = 9):
        """
        Calculate MACD (Moving Average Convergence Divergence)
        
        Args:
            data (pd.Series): Price data
            fast_period (int): Fast EMA period
            slow_period (int): Slow EMA period
            signal_period (int): Signal line EMA period
            
        Returns:
            tuple: (macd_line, signal_line, histogram)
        """
        ema_fast = self.exponential_moving_average(data, fast_period)
        ema_slow = self.exponential_moving_average(data, slow_period)
        macd_line = ema_fast - ema_slow
        signal_line = self.exponential_moving_average(macd_line, signal_period)
        histogram = macd_line - signal_line
        return macd_line, signal_line, histogram
    
    def bollinger_bands(self, data: pd.Series, window: int = 20, num_std: float = 2):
        """
        Calculate Bollinger Bands
        
        Args:
            data (pd.Series): Price data
            window (int): Window size
            num_std (float): Number of standard deviations
            
        Returns:
            tuple: (upper_band, middle_band, lower_band)
        """
        middle_band = data.rolling(window=window).mean()
        std_dev = data.rolling(window=window).std()
        upper_band = middle_band + (std_dev * num_std)
        lower_band = middle_band - (std_dev * num_std)
        return upper_band, middle_band, lower_band
    
    def stochastic_oscillator(self, high: pd.Series, low: pd.Series, close: pd.Series, k_period: int = 14, d_period: int = 3):
        """
        Calculate Stochastic Oscillator
        
        Args:
            high (pd.Series): High prices
            low (pd.Series): Low prices
            close (pd.Series): Close prices
            k_period (int): %K period
            d_period (int): %D period
            
        Returns:
            tuple: (%K, %D)
        """
        lowest_low = low.rolling(window=k_period).min()
        highest_high = high.rolling(window=k_period).max()
        k_percent = 100 * ((close - lowest_low) / (highest_high - lowest_low))
        d_percent = k_percent.rolling(window=d_period).mean()
        return k_percent, d_percent
    
    def atr(self, high: pd.Series, low: pd.Series, close: pd.Series, window: int = 14) -> pd.Series:
        """
        Calculate Average True Range
        
        Args:
            high (pd.Series): High prices
            low (pd.Series): Low prices
            close (pd.Series): Close prices
            window (int): Window size
            
        Returns:
            pd.Series: ATR values
        """
        prev_close = close.shift(1)
        tr1 = high - low
        tr2 = abs(high - prev_close)
        tr3 = abs(low - prev_close)
        true_range = pd.concat([tr1, tr2, tr3], axis=1).max(axis=1)
        return true_range.rolling(window=window).mean()
    
    def williams_r(self, high: pd.Series, low: pd.Series, close: pd.Series, window: int = 14) -> pd.Series:
        """
        Calculate Williams %R
        
        Args:
            high (pd.Series): High prices
            low (pd.Series): Low prices
            close (pd.Series): Close prices
            window (int): Window size
            
        Returns:
            pd.Series: Williams %R values
        """
        highest_high = high.rolling(window=window).max()
        lowest_low = low.rolling(window=window).min()
        return -100 * (highest_high - close) / (highest_high - lowest_low)
    
    def fibonacci_retracement(self, high_price: float, low_price: float):
        """
        Calculate Fibonacci retracement levels
        
        Args:
            high_price (float): High price
            low_price (float): Low price
            
        Returns:
            dict: Fibonacci levels
        """
        diff = high_price - low_price
        levels = {
            '0%': high_price,
            '23.6%': high_price - 0.236 * diff,
            '38.2%': high_price - 0.382 * diff,
            '50%': high_price - 0.5 * diff,
            '61.8%': high_price - 0.618 * diff,
            '78.6%': high_price - 0.786 * diff,
            '100%': low_price
        }
        return levels
    
    def detect_support_resistance(self, data: pd.Series, window: int = 20, min_touches: int = 2):
        """
        Detect support and resistance levels
        
        Args:
            data (pd.Series): Price data
            window (int): Window for local extrema
            min_touches (int): Minimum touches for level confirmation
            
        Returns:
            tuple: (support_levels, resistance_levels)
        """
        # Find local maxima and minima
        highs = data.rolling(window=window, center=True).max() == data
        lows = data.rolling(window=window, center=True).min() == data
        
        resistance_levels = []
        support_levels = []
        
        # Extract resistance levels (local highs)
        resistance_prices = data[highs].dropna()
        for price in resistance_prices:
            # Count how many times price was near this level
            touches = len(data[(data >= price * 0.98) & (data <= price * 1.02)])
            if touches >= min_touches:
                resistance_levels.append(price)
        
        # Extract support levels (local lows)
        support_prices = data[lows].dropna()
        for price in support_prices:
            touches = len(data[(data >= price * 0.98) & (data <= price * 1.02)])
            if touches >= min_touches:
                support_levels.append(price)
        
        return sorted(set(support_levels)), sorted(set(resistance_levels), reverse=True)
    
    def generate_signals(self, data: pd.DataFrame):
        """
        Generate trading signals based on multiple indicators
        
        Args:
            data (pd.DataFrame): OHLCV data
            
        Returns:
            pd.DataFrame: DataFrame with signals
        """
        signals = pd.DataFrame(index=data.index)
        
        # Calculate indicators
        signals['RSI'] = self.rsi(data['Close'])
        macd_line, macd_signal, _ = self.macd(data['Close'])
        signals['MACD'] = macd_line
        signals['MACD_Signal'] = macd_signal
        signals['MA_20'] = self.moving_average(data['Close'], 20)
        signals['MA_50'] = self.moving_average(data['Close'], 50)
        
        # Generate buy/sell signals
        signals['RSI_Buy'] = signals['RSI'] < 30
        signals['RSI_Sell'] = signals['RSI'] > 70
        
        signals['MACD_Buy'] = (signals['MACD'] > signals['MACD_Signal']) & (signals['MACD'].shift(1) <= signals['MACD_Signal'].shift(1))
        signals['MACD_Sell'] = (signals['MACD'] < signals['MACD_Signal']) & (signals['MACD'].shift(1) >= signals['MACD_Signal'].shift(1))
        
        signals['MA_Buy'] = (signals['MA_20'] > signals['MA_50']) & (data['Close'] > signals['MA_20'])
        signals['MA_Sell'] = (signals['MA_20'] < signals['MA_50']) & (data['Close'] < signals['MA_20'])
        
        # Combine signals
        signals['Buy_Signal'] = (signals['RSI_Buy'] | signals['MACD_Buy'] | signals['MA_Buy'])
        signals['Sell_Signal'] = (signals['RSI_Sell'] | signals['MACD_Sell'] | signals['MA_Sell'])
        
        return signals

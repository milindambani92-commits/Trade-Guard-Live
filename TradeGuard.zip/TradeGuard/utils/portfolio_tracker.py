import pandas as pd
import numpy as np
import streamlit as st
from datetime import datetime, timedelta
import plotly.graph_objects as go
import plotly.express as px
from utils.data_fetcher import DataFetcher
from utils.risk_management import RiskManager

class PortfolioTracker:
    """
    Portfolio tracking and performance analysis
    """
    
    def __init__(self):
        self.data_fetcher = DataFetcher()
        self.risk_manager = RiskManager()
    
    def add_position(self, symbol: str, shares: int, entry_price: float, 
                    entry_date: str = None, position_type: str = "long"):
        """
        Add a position to the portfolio
        
        Args:
            symbol (str): Stock symbol
            shares (int): Number of shares
            entry_price (float): Entry price per share
            entry_date (str): Entry date (YYYY-MM-DD)
            position_type (str): "long" or "short"
        """
        if 'portfolio_positions' not in st.session_state:
            st.session_state.portfolio_positions = []
        
        if entry_date is None:
            entry_date = datetime.now().strftime('%Y-%m-%d')
        
        position = {
            'symbol': symbol.upper(),
            'shares': shares,
            'entry_price': entry_price,
            'entry_date': entry_date,
            'position_type': position_type,
            'entry_value': shares * entry_price
        }
        
        st.session_state.portfolio_positions.append(position)
    
    def remove_position(self, index: int):
        """
        Remove a position from the portfolio
        
        Args:
            index (int): Position index
        """
        if 'portfolio_positions' in st.session_state and 0 <= index < len(st.session_state.portfolio_positions):
            st.session_state.portfolio_positions.pop(index)
    
    def get_portfolio_summary(self):
        """
        Get portfolio summary with current values and P&L
        
        Returns:
            pd.DataFrame: Portfolio summary
        """
        if 'portfolio_positions' not in st.session_state or not st.session_state.portfolio_positions:
            return pd.DataFrame()
        
        portfolio_data = []
        
        for position in st.session_state.portfolio_positions:
            symbol = position['symbol']
            
            # Get current price
            current_price = self.data_fetcher.get_real_time_price(symbol)
            
            if current_price is not None:
                current_value = position['shares'] * current_price
                total_pl = current_value - position['entry_value']
                pl_percentage = (total_pl / position['entry_value']) * 100 if position['entry_value'] != 0 else 0
                
                # Adjust for short positions
                if position['position_type'] == 'short':
                    total_pl = -total_pl
                    pl_percentage = -pl_percentage
                
                portfolio_data.append({
                    'Symbol': symbol,
                    'Shares': position['shares'],
                    'Entry Price': position['entry_price'],
                    'Current Price': current_price,
                    'Entry Value': position['entry_value'],
                    'Current Value': current_value,
                    'Total P&L': total_pl,
                    'P&L %': pl_percentage,
                    'Entry Date': position['entry_date'],
                    'Position Type': position['position_type'].capitalize()
                })
            else:
                # If we can't get current price, show entry values
                portfolio_data.append({
                    'Symbol': symbol,
                    'Shares': position['shares'],
                    'Entry Price': position['entry_price'],
                    'Current Price': 'N/A',
                    'Entry Value': position['entry_value'],
                    'Current Value': 'N/A',
                    'Total P&L': 'N/A',
                    'P&L %': 'N/A',
                    'Entry Date': position['entry_date'],
                    'Position Type': position['position_type'].capitalize()
                })
        
        return pd.DataFrame(portfolio_data)
    
    def calculate_portfolio_metrics(self):
        """
        Calculate portfolio-wide metrics
        
        Returns:
            dict: Portfolio metrics
        """
        portfolio_df = self.get_portfolio_summary()
        
        if portfolio_df.empty:
            return {}
        
        # Filter out positions where we couldn't get current price
        valid_positions = portfolio_df[portfolio_df['Current Value'] != 'N/A'].copy()
        
        if valid_positions.empty:
            return {}
        
        metrics = {}
        
        # Basic metrics
        metrics['Total Entry Value'] = valid_positions['Entry Value'].sum()
        metrics['Total Current Value'] = valid_positions['Current Value'].sum()
        metrics['Total P&L'] = valid_positions['Total P&L'].sum()
        metrics['Total P&L %'] = (metrics['Total P&L'] / metrics['Total Entry Value']) * 100 if metrics['Total Entry Value'] != 0 else 0
        
        # Risk metrics
        metrics['Number of Positions'] = len(valid_positions)
        metrics['Largest Position %'] = (valid_positions['Current Value'].max() / metrics['Total Current Value']) * 100 if metrics['Total Current Value'] != 0 else 0
        
        # Winners vs Losers
        winners = valid_positions[valid_positions['Total P&L'] > 0]
        losers = valid_positions[valid_positions['Total P&L'] < 0]
        
        metrics['Winning Positions'] = len(winners)
        metrics['Losing Positions'] = len(losers)
        metrics['Win Rate'] = (len(winners) / len(valid_positions)) * 100 if len(valid_positions) > 0 else 0
        
        if len(winners) > 0:
            metrics['Avg Winner'] = winners['Total P&L'].mean()
        else:
            metrics['Avg Winner'] = 0
            
        if len(losers) > 0:
            metrics['Avg Loser'] = losers['Total P&L'].mean()
        else:
            metrics['Avg Loser'] = 0
        
        return metrics
    
    def get_sector_allocation(self):
        """
        Get sector allocation of the portfolio (simplified - would need proper sector data)
        
        Returns:
            dict: Sector allocation
        """
        portfolio_df = self.get_portfolio_summary()
        
        if portfolio_df.empty:
            return {}
        
        # Simplified sector mapping (in real app, would use proper API)
        sector_map = {
            'AAPL': 'Technology', 'MSFT': 'Technology', 'GOOGL': 'Technology', 'AMZN': 'Consumer Discretionary',
            'TSLA': 'Consumer Discretionary', 'NVDA': 'Technology', 'META': 'Technology',
            'JPM': 'Financials', 'JNJ': 'Healthcare', 'V': 'Technology',
            'WMT': 'Consumer Staples', 'PG': 'Consumer Staples', 'HD': 'Consumer Discretionary',
            'UNH': 'Healthcare', 'DIS': 'Communication Services', 'BAC': 'Financials'
        }
        
        sector_allocation = {}
        total_value = 0
        
        valid_positions = portfolio_df[portfolio_df['Current Value'] != 'N/A'].copy()
        
        for _, position in valid_positions.iterrows():
            symbol = position['Symbol']
            value = position['Current Value']
            sector = sector_map.get(symbol, 'Other')
            
            if sector in sector_allocation:
                sector_allocation[sector] += value
            else:
                sector_allocation[sector] = value
            
            total_value += value
        
        # Convert to percentages
        for sector in sector_allocation:
            sector_allocation[sector] = (sector_allocation[sector] / total_value) * 100 if total_value != 0 else 0
        
        return sector_allocation
    
    def create_portfolio_charts(self):
        """
        Create portfolio visualization charts
        
        Returns:
            dict: Dictionary of plotly figures
        """
        portfolio_df = self.get_portfolio_summary()
        charts = {}
        
        if portfolio_df.empty:
            return charts
        
        valid_positions = portfolio_df[portfolio_df['Current Value'] != 'N/A'].copy()
        
        if valid_positions.empty:
            return charts
        
        # Portfolio allocation pie chart
        fig_allocation = px.pie(
            values=valid_positions['Current Value'],
            names=valid_positions['Symbol'],
            title='Portfolio Allocation by Value'
        )
        charts['allocation'] = fig_allocation
        
        # P&L bar chart
        fig_pl = px.bar(
            x=valid_positions['Symbol'],
            y=valid_positions['Total P&L'],
            color=valid_positions['Total P&L'],
            color_continuous_scale=['red', 'white', 'green'],
            title='Profit & Loss by Position'
        )
        fig_pl.update_layout(showlegend=False)
        charts['pl_chart'] = fig_pl
        
        # Sector allocation (if available)
        sector_data = self.get_sector_allocation()
        if sector_data:
            fig_sector = px.pie(
                values=list(sector_data.values()),
                names=list(sector_data.keys()),
                title='Portfolio Allocation by Sector'
            )
            charts['sector_allocation'] = fig_sector
        
        return charts
    
    def calculate_historical_performance(self, days: int = 30):
        """
        Calculate historical portfolio performance
        
        Args:
            days (int): Number of days to look back
            
        Returns:
            pd.DataFrame: Historical performance data
        """
        if 'portfolio_positions' not in st.session_state or not st.session_state.portfolio_positions:
            return pd.DataFrame()
        
        # Get unique symbols
        symbols = list(set([pos['symbol'] for pos in st.session_state.portfolio_positions]))
        
        # Fetch historical data for all symbols
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        
        portfolio_values = []
        dates = []
        
        try:
            # Get first trading day to establish baseline
            first_symbol_data = self.data_fetcher.get_stock_data(symbols[0], f"{days}d")
            if first_symbol_data is not None and not first_symbol_data.empty:
                dates = first_symbol_data.index.tolist()
                
                for date in dates:
                    daily_value = 0
                    
                    for position in st.session_state.portfolio_positions:
                        symbol = position['symbol']
                        shares = position['shares']
                        
                        # Get price for this date
                        symbol_data = self.data_fetcher.get_stock_data(symbol, f"{days}d")
                        if symbol_data is not None and date in symbol_data.index:
                            price = symbol_data.loc[date, 'Close']
                            daily_value += shares * price
                    
                    portfolio_values.append(daily_value)
                
                performance_df = pd.DataFrame({
                    'Date': dates,
                    'Portfolio Value': portfolio_values
                })
                
                # Calculate returns
                performance_df['Daily Return'] = performance_df['Portfolio Value'].pct_change()
                performance_df['Cumulative Return'] = (performance_df['Portfolio Value'] / performance_df['Portfolio Value'].iloc[0] - 1) * 100
                
                return performance_df
                
        except Exception as e:
            st.error(f"Error calculating historical performance: {str(e)}")
        
        return pd.DataFrame()
    
    def export_portfolio_data(self):
        """
        Export portfolio data to CSV format
        
        Returns:
            str: CSV string
        """
        portfolio_df = self.get_portfolio_summary()
        
        if portfolio_df.empty:
            return ""
        
        return portfolio_df.to_csv(index=False)
    
    def get_risk_analysis(self):
        """
        Perform risk analysis on the portfolio
        
        Returns:
            dict: Risk analysis results
        """
        portfolio_df = self.get_portfolio_summary()
        
        if portfolio_df.empty:
            return {}
        
        valid_positions = portfolio_df[portfolio_df['Current Value'] != 'N/A'].copy()
        
        if valid_positions.empty:
            return {}
        
        risk_analysis = {}
        
        # Concentration risk
        total_value = valid_positions['Current Value'].sum()
        max_position = valid_positions['Current Value'].max()
        risk_analysis['Concentration Risk'] = (max_position / total_value) * 100 if total_value != 0 else 0
        
        # Diversification score (simple version)
        num_positions = len(valid_positions)
        if num_positions <= 1:
            risk_analysis['Diversification Score'] = 0
        elif num_positions <= 5:
            risk_analysis['Diversification Score'] = 25
        elif num_positions <= 10:
            risk_analysis['Diversification Score'] = 50
        elif num_positions <= 20:
            risk_analysis['Diversification Score'] = 75
        else:
            risk_analysis['Diversification Score'] = 100
        
        # Volatility estimate (based on individual stock volatilities)
        total_volatility = 0
        for _, position in valid_positions.iterrows():
            symbol = position['Symbol']
            weight = position['Current Value'] / total_value
            
            # Get 30-day data to estimate volatility
            stock_data = self.data_fetcher.get_stock_data(symbol, "1mo")
            if stock_data is not None and not stock_data.empty:
                returns = stock_data['Close'].pct_change().dropna()
                if not returns.empty:
                    volatility = returns.std() * np.sqrt(252)  # Annualized
                    total_volatility += weight * volatility
        
        risk_analysis['Estimated Annual Volatility'] = total_volatility * 100
        
        # Risk level classification
        if risk_analysis['Estimated Annual Volatility'] < 15:
            risk_analysis['Risk Level'] = 'Low'
        elif risk_analysis['Estimated Annual Volatility'] < 25:
            risk_analysis['Risk Level'] = 'Moderate'
        elif risk_analysis['Estimated Annual Volatility'] < 35:
            risk_analysis['Risk Level'] = 'High'
        else:
            risk_analysis['Risk Level'] = 'Very High'
        
        return risk_analysis

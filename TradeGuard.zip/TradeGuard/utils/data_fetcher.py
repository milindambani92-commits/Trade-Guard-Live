import yfinance as yf
import pandas as pd
import streamlit as st
from datetime import datetime, timedelta
import time

class DataFetcher:
    def __init__(self):
        self.cache_duration = 300  # 5 minutes cache
    
    @st.cache_data(ttl=300)
    def get_stock_data(self, symbol: str, period: str = "1y", interval: str = "1d"):
        """
        Fetch stock data using yfinance
        
        Args:
            symbol (str): Stock symbol (e.g., 'AAPL')
            period (str): Time period ('1d', '5d', '1mo', '3mo', '6mo', '1y', '2y', '5y', '10y', 'ytd', 'max')
            interval (str): Data interval ('1m', '2m', '5m', '15m', '30m', '60m', '90m', '1h', '1d', '5d', '1wk', '1mo', '3mo')
        
        Returns:
            pd.DataFrame: Stock data with OHLCV columns
        """
        try:
            ticker = yf.Ticker(symbol)
            data = ticker.history(period=period, interval=interval)
            
            if data.empty:
                st.warning(f"No data found for symbol {symbol}")
                return None
            
            return data
            
        except Exception as e:
            st.error(f"Error fetching data for {symbol}: {str(e)}")
            return None
    
    @st.cache_data(ttl=300)
    def get_stock_info(self, symbol: str):
        """
        Get stock information and metadata
        
        Args:
            symbol (str): Stock symbol
            
        Returns:
            dict: Stock information
        """
        try:
            ticker = yf.Ticker(symbol)
            info = ticker.info
            return info
        except Exception as e:
            st.error(f"Error fetching info for {symbol}: {str(e)}")
            return {}
    
    @st.cache_data(ttl=600)
    def get_multiple_stocks(self, symbols: list, period: str = "1mo"):
        """
        Fetch data for multiple stocks
        
        Args:
            symbols (list): List of stock symbols
            period (str): Time period
            
        Returns:
            dict: Dictionary with symbol as key and data as value
        """
        stock_data = {}
        
        for symbol in symbols:
            data = self.get_stock_data(symbol, period)
            if data is not None:
                stock_data[symbol] = data
        
        return stock_data
    
    @st.cache_data(ttl=3600)
    def get_market_indices(self):
        """
        Get major market indices data
        
        Returns:
            dict: Dictionary with index data
        """
        indices = {
            'S&P 500': '^GSPC',
            'Dow Jones': '^DJI',
            'NASDAQ': '^IXIC',
            'Russell 2000': '^RUT',
            'VIX': '^VIX'
        }
        
        index_data = {}
        for name, symbol in indices.items():
            data = self.get_stock_data(symbol, period="5d")
            if data is not None:
                index_data[name] = data
        
        return index_data
    
    def get_real_time_price(self, symbol: str):
        """
        Get real-time price (as real-time as yfinance allows)
        
        Args:
            symbol (str): Stock symbol
            
        Returns:
            float: Current price
        """
        try:
            ticker = yf.Ticker(symbol)
            data = ticker.history(period="1d", interval="1m")
            if not data.empty:
                return data['Close'].iloc[-1]
            else:
                # Fallback to daily data
                data = ticker.history(period="2d", interval="1d")
                if not data.empty:
                    return data['Close'].iloc[-1]
        except Exception as e:
            st.error(f"Error fetching real-time price for {symbol}: {str(e)}")
        
        return None
    
    @st.cache_data(ttl=1800)
    def get_sector_performance(self):
        """
        Get sector ETF performance
        
        Returns:
            dict: Sector performance data
        """
        sector_etfs = {
            'Technology': 'XLK',
            'Healthcare': 'XLV',
            'Financials': 'XLF',
            'Consumer Discretionary': 'XLY',
            'Communication Services': 'XLC',
            'Industrials': 'XLI',
            'Consumer Staples': 'XLP',
            'Energy': 'XLE',
            'Utilities': 'XLU',
            'Real Estate': 'XLRE',
            'Materials': 'XLB'
        }
        
        sector_data = {}
        for sector, etf in sector_etfs.items():
            data = self.get_stock_data(etf, period="1mo")
            if data is not None:
                sector_data[sector] = data
        
        return sector_data
